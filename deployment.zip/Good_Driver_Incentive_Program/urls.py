"""
URL configuration for Good_Driver_Incentive_Program project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
from django.urls import re_path
from .react_frontend import react_frontend

urlpatterns = [
    path('', include('accounts.urls')),
    path('admin/', admin.site.urls),
    path('api/about/', include('about.urls')),
    path('catalog/', include('catalog.urls')),
    path("api/catalog/", include("catalog.api_urls")),
    re_path(r"^app(?:/.*)?$", react_frontend),
]
